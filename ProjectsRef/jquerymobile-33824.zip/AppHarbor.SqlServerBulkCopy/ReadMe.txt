﻿AppHarbor SQL Backup and restore
1. First create destination user, password, DB and scheama
2. Run bat file as a push or pull
http://support.appharbor.com/discussions/problems/189-ms-sql-database-backup-and-restore
https://github.com/appharbor/AppHarbor-SqlServerBulkCopy