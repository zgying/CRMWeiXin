﻿CREATE TABLE [dbo].[SurveyResults] (
    [ResultID]   INT      IDENTITY (1, 1) NOT NULL,
    [CreateDate] DATETIME NOT NULL,
    [PortalID]   INT      NOT NULL
);





