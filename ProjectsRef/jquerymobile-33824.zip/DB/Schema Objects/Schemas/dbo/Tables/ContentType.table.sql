﻿CREATE TABLE [dbo].[ContentType] (
    [ContentTypeID] INT           IDENTITY (1, 1) NOT NULL,
    [Name]          NVARCHAR (50) NOT NULL
);

